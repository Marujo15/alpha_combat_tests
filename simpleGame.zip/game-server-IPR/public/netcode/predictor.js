class Predictor {
    constructor() {
        this.pendingInputs = [];
    }

    predictMovement(player, input, sequence) {
        const predictedState = {
            x: player.x,
            y: player.y,
            color: player.color
        };

        // Apply input to get predicted state
        if (input.left) predictedState.x -= 5;
        if (input.right) predictedState.x += 5;
        if (input.up) predictedState.y -= 5;
        if (input.down) predictedState.y += 5;

        // Simple collision with canvas boundaries
        predictedState.x = Math.max(0, Math.min(800 - 50, predictedState.x));
        predictedState.y = Math.max(0, Math.min(600 - 50, predictedState.y));

        this.pendingInputs.push({
            input,
            sequence,
            predictedState: { ...predictedState }
        });

        return predictedState;
    }
}
class Interpolator {
    constructor() {
        this.stateBuffer = [];
        this.interpolationDelay = 100; // 100ms interpolation delay
    }

    addState(state, timestamp) {
        this.stateBuffer.push({ state, timestamp });

        // Keep only last second of states
        const bufferDuration = 1000;
        const cutoff = timestamp - bufferDuration;
        this.stateBuffer = this.stateBuffer.filter(item => item.timestamp > cutoff);
    }

    interpolate(renderTimestamp) {
        // Target time is current time minus interpolation delay
        const targetTime = renderTimestamp - this.interpolationDelay;

        // Find the two states to interpolate between
        let beforeState = null;
        let afterState = null;

        for (let i = 0; i < this.stateBuffer.length; i++) {
            if (this.stateBuffer[i].timestamp > targetTime) {
                afterState = this.stateBuffer[i];
                beforeState = this.stateBuffer[i - 1];
                break;
            }
        }

        if (!beforeState || !afterState) {
            return this.stateBuffer[this.stateBuffer.length - 1]?.state;
        }

        // Calculate interpolation factor
        const totalTime = afterState.timestamp - beforeState.timestamp;
        const currentTime = targetTime - beforeState.timestamp;
        const t = currentTime / totalTime;

        // Linear interpolation between states
        return {
            x: beforeState.state.x + (afterState.state.x - beforeState.state.x) * t,
            y: beforeState.state.y + (afterState.state.y - beforeState.state.y) * t,
            color: beforeState.state.color
        };
    }
}
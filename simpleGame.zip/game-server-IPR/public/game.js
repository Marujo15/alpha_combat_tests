const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const ws = new WebSocket(`ws://${window.location.host}`);
let playerId = null;
let players = new Map();
let currentInput = { up: false, down: false, left: false, right: false };
let inputSequence = 0;

// Initialize netcode components
const predictor = new Predictor();
const reconciler = new Reconciler(predictor);
const interpolator = new Interpolator();

ws.onmessage = (event) => {
    const message = JSON.parse(event.data);

    switch (message.type) {
        case 'init':
            playerId = message.playerId;
            message.gameState.forEach(([id, state]) => {
                players.set(id, state);
            });
            break;

        case 'worldState':
            const timestamp = Date.now();

            // Handle own player with reconciliation
            const serverPlayer = message.worldState.find(([id]) => id === playerId)?.[1];
            if (serverPlayer) {
                const lastProcessedInput = message.lastProcessedInputs.find(([id]) => id === playerId)?.[1];
                const reconciledState = reconciler.reconcile(serverPlayer, lastProcessedInput);
                players.set(playerId, reconciledState);
            }

            // Handle other players with interpolation
            message.worldState.forEach(([id, state]) => {
                if (id !== playerId) {
                    interpolator.addState(state, timestamp);
                }
            });
            break;
    }
};

// Input handling
const keys = {
    'ArrowUp': 'up',
    'ArrowDown': 'down',
    'ArrowLeft': 'left',
    'ArrowRight': 'right'
};

window.addEventListener('keydown', (e) => {
    if (keys[e.key]) {
        currentInput[keys[e.key]] = true;
    }
});

window.addEventListener('keyup', (e) => {
    if (keys[e.key]) {
        currentInput[keys[e.key]] = false;
    }
});

// Game loop
function gameLoop() {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Send input to server and predict own movement
    if (playerId && players.has(playerId)) {
        const player = players.get(playerId);
        inputSequence++;

        // Send input to server
        ws.send(JSON.stringify({
            type: 'input',
            input: currentInput,
            sequence: inputSequence
        }));

        // Predict movement
        const predictedState = predictor.predictMovement(player, currentInput, inputSequence);
        players.set(playerId, predictedState);
    }

    // Render all players
    const renderTimestamp = Date.now();

    players.forEach((player, id) => {
        if (id === playerId) {
            // Render own player
            ctx.fillStyle = player.color;
            ctx.fillRect(player.x, player.y, 50, 50);
        } else {
            // Render other players with interpolation
            const interpolatedState = interpolator.interpolate(renderTimestamp);
            if (interpolatedState) {
                ctx.fillStyle = interpolatedState.color;
                ctx.fillRect(interpolatedState.x, interpolatedState.y, 50, 50);
            }
        }
    });

    requestAnimationFrame(gameLoop);
}

gameLoop();
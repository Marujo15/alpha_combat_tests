const express = require('express');
const http = require('http');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.static('public'));

// Game state
const gameState = {
    players: new Map(),
    lastProcessedInput: new Map(),
};

const TICK_RATE = 20;
const PLAYER_SPEED = 5;

// Process player input and update game state
function processInput(playerId, input, sequence) {
    const player = gameState.players.get(playerId);
    if (!player) return;

    // Store last processed input for reconciliation
    gameState.lastProcessedInput.set(playerId, sequence);

    // Update player position based on input
    if (input.left) player.x -= PLAYER_SPEED;
    if (input.right) player.x += PLAYER_SPEED;
    if (input.up) player.y -= PLAYER_SPEED;
    if (input.down) player.y += PLAYER_SPEED;

    // Simple collision with canvas boundaries
    player.x = Math.max(0, Math.min(800 - 50, player.x));
    player.y = Math.max(0, Math.min(600 - 50, player.y));
}

wss.on('connection', (ws) => {
    const playerId = Date.now().toString();
    console.log(`Player ${playerId} connected`);

    // Initialize player
    gameState.players.set(playerId, {
        x: Math.random() * (800 - 50),
        y: Math.random() * (600 - 50),
        color: `#${Math.floor(Math.random() * 16777215).toString(16)}`
    });

    // Send initial state
    ws.send(JSON.stringify({
        type: 'init',
        playerId,
        gameState: Array.from(gameState.players.entries())
    }));

    ws.on('message', (message) => {
        const data = JSON.parse(message);

        if (data.type === 'input') {
            processInput(playerId, data.input, data.sequence);
        }
    });

    ws.on('close', () => {
        console.log(`Player ${playerId} disconnected`);
        gameState.players.delete(playerId);
        gameState.lastProcessedInput.delete(playerId);
    });
});

// Game loop
setInterval(() => {
    const worldState = Array.from(gameState.players.entries());
    const lastInputs = Array.from(gameState.lastProcessedInput.entries());

    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({
                type: 'worldState',
                worldState,
                lastProcessedInputs: lastInputs
            }));
        }
    });
}, 1000 / TICK_RATE);

server.listen(3000, () => {
    console.log('Server running on port 3000');
});
class Reconciler {
    constructor(predictor) {
        this.predictor = predictor;
    }

    reconcile(serverState, lastProcessedInputSequence) {
        // Remove processed inputs
        this.predictor.pendingInputs = this.predictor.pendingInputs.filter(
            input => input.sequence > lastProcessedInputSequence
        );

        // Re-apply remaining inputs
        let reconciledState = { ...serverState };

        this.predictor.pendingInputs.forEach(({ input }) => {
            if (input.left) reconciledState.x -= 5;
            if (input.right) reconciledState.x += 5;
            if (input.up) reconciledState.y -= 5;
            if (input.down) reconciledState.y += 5;

            // Simple collision with canvas boundaries
            reconciledState.x = Math.max(0, Math.min(800 - 50, reconciledState.x));
            reconciledState.y = Math.max(0, Math.min(600 - 50, reconciledState.y));
        });

        return reconciledState;
    }
}